# nitnom
a python package to make you lfe easier