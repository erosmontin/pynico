# pynico
a python package to make your life simpler, at least mine